require "prototypes.global-robot-combinator"
